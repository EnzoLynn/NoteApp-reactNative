var pushState = {
   on:false,
   yArr:[],
   top:true
};
module.exports = pushState;