var dd = "ddd";


module.exports = dd;