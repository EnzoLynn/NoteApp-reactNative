 var config = {
     'req_url': "http://192.168.91.101:818/data/movies.json",
     'req_url3000': "http://192.168.91.101:3000"
 };
 module.exports = config;
